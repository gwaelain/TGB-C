from cashback import get_cashback
from aiogram import Bot, Dispatcher, types
bot = Bot(token='')
dp = Dispatcher(bot)


@dp.message_handler(commands=["кэшбэк"])
async def cashback_info(message: types.Message):
    category = message.get_args().strip().lower()
    if not category:
        await message.answer("Укажи категорию: еда, косметика, дети, прочее. Пример: /кэшбэк еда")
        return
    info = get_cashback(category)
    await message.answer(f"💸 {info}")


@dp.message_handler(commands=["добавить_покупку"])
async def add_purchase_command(message: types.Message):
    args = message.get_args().split()
    if len(args) < 2:
        await message.answer("Пример: /добавить_покупку молоко 89")
        return
    product = " ".join(args[:-1])
    try:
        price = float(args[-1])
    except ValueError:
        await message.answer("Укажите корректную сумму.")
        return
    category = classify_category(product)
    add_purchase(message.from_user.id, product, price, category)
    await message.answer(f"✅ Сохранено: {product} — {price} ₽ ({category})")
    cashback = get_cashback(category)
    await message.answer(f"💸 Рекомендованный кэшбэк: {cashback}")
